package com.staywell.exception;

@SuppressWarnings("serial")
public class AdminException extends RuntimeException {

	public AdminException(String message) {
		super(message);
	}

}
