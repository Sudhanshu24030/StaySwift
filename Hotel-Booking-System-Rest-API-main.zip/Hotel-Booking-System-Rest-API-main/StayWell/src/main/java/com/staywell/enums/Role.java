package com.staywell.enums;

public enum Role {
	ROLE_ADMIN, ROLE_CUSTOMER, ROLE_HOTEL;
}
