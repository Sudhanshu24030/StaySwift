package com.staywell.enums;

public enum ReservationStatus {

	BOOKED, CLOSED
}
