package com.staywell.exception;

@SuppressWarnings("serial")
public class ReservationException extends RuntimeException {

	public ReservationException(String message) {
		super(message);
	}

}
