package com.staywell.enums;

public enum RoomType {

	AC, NON_AC

}
