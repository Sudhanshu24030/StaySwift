package com.staywell.exception;

@SuppressWarnings("serial")
public class HotelException extends RuntimeException {

	public HotelException(String message) {
		super(message);
	}

}
