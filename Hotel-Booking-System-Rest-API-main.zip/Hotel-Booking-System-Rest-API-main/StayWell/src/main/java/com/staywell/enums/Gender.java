package com.staywell.enums;

public enum Gender {
	MALE,FEMALE,OTHER;
}
