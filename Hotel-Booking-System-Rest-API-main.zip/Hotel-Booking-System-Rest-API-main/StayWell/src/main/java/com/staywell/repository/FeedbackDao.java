package com.staywell.repository;

public interface FeedbackDao {

}
