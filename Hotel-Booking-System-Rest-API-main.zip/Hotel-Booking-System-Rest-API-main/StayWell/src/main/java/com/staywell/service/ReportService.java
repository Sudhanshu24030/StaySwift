package com.staywell.service;

public interface ReportService {

}
