package com.staywell.enums;

public enum PaymentType {

	DEBITCARD, CREDITCARD, UPI, NETBANKING
}
