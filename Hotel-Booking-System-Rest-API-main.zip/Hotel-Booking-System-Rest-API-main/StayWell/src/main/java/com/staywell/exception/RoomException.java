package com.staywell.exception;

@SuppressWarnings("serial")
public class RoomException extends RuntimeException {

	public RoomException(String message) {
		super(message);
	}

}
